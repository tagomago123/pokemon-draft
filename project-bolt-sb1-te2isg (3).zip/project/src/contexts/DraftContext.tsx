import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { DraftUser, Pokemon } from '../types';
import { useSocket } from './SocketContext';

interface DraftState {
  users: DraftUser[];
  currentTurn: number;
  admin: string | null;
  maxUsers: number;
  isReversed: boolean;
  currentRound: number;
}

type DraftAction = 
  | { type: 'ADD_USER'; payload: { name: string; id: string } }
  | { type: 'SELECT_POKEMON'; payload: { userId: string; pokemon: Pokemon } }
  | { type: 'UNDO_LAST_SELECTION'; payload: { userId: string } }
  | { type: 'UPDATE_USER_NAME'; payload: { userId: string; name: string } }
  | { type: 'SET_MAX_USERS'; payload: number }
  | { type: 'SET_STATE'; payload: DraftState }
  | { type: 'RESET_DRAFT' };

const initialState: DraftState = {
  users: [],
  currentTurn: 0,
  admin: null,
  maxUsers: 2,
  isReversed: false,
  currentRound: 1,
};

function draftReducer(state: DraftState = initialState, action: DraftAction): DraftState {
  switch (action.type) {
    case 'SET_STATE':
      return action.payload ? { ...action.payload } : state;
      
    case 'ADD_USER': {
      if (!state || state.users.length >= state.maxUsers) {
        return state;
      }
      const isFirstUser = !state.users || state.users.length === 0;
      return {
        ...state,
        users: [...(state.users || []), { id: action.payload.id, name: action.payload.name, selections: [] }],
        admin: isFirstUser ? action.payload.id : state.admin,
      };
    }

    case 'SELECT_POKEMON': {
      if (!state || !state.users) return state;
      
      const userIndex = state.users.findIndex(u => u.id === action.payload.userId);
      if (userIndex !== state.currentTurn) return state;

      const nextTurn = state.isReversed
        ? state.currentTurn > 0 ? state.currentTurn - 1 : 0
        : state.currentTurn < state.users.length - 1 ? state.currentTurn + 1 : state.users.length - 1;

      const newIsReversed = state.isReversed
        ? state.currentTurn === 0 ? false : state.isReversed
        : state.currentTurn === state.users.length - 1 ? true : state.isReversed;

      const roundIncrement = state.isReversed && state.currentTurn === 0 ? 1 : 0;

      return {
        ...state,
        users: state.users.map(user =>
          user.id === action.payload.userId
            ? { ...user, selections: [...(user.selections || []), action.payload.pokemon] }
            : user
        ),
        currentTurn: nextTurn,
        isReversed: newIsReversed,
        currentRound: state.currentRound + roundIncrement,
      };
    }

    case 'UNDO_LAST_SELECTION': {
      if (!state || !state.users) return state;
      
      return {
        ...state,
        users: state.users.map(user =>
          user.id === action.payload.userId && user.selections
            ? { ...user, selections: user.selections.slice(0, -1) }
            : user
        ),
      };
    }

    case 'UPDATE_USER_NAME': {
      if (!state || !state.users) return state;
      
      return {
        ...state,
        users: state.users.map(user =>
          user.id === action.payload.userId
            ? { ...user, name: action.payload.name }
            : user
        ),
      };
    }

    case 'SET_MAX_USERS': {
      if (!state || state.users.length > 0) return state;
      return {
        ...state,
        maxUsers: action.payload,
      };
    }

    case 'RESET_DRAFT':
      return initialState;

    default:
      return state;
  }
}

const DraftContext = createContext<{
  state: DraftState;
  dispatch: React.Dispatch<DraftAction>;
}>({
  state: initialState,
  dispatch: () => null,
});

export function DraftProvider({ children }: { children: React.ReactNode }) {
  const [state, localDispatch] = useReducer(draftReducer, initialState);
  const { socket, roomId } = useSocket();

  const dispatch = useCallback((action: DraftAction) => {
    if (socket && roomId) {
      socket.emit('draft_action', { roomId, action });
    }
    localDispatch(action);
  }, [socket, roomId]);

  useEffect(() => {
    if (!socket) return;

    socket.on('state_updated', (newState: DraftState) => {
      if (newState) {
        localDispatch({ type: 'SET_STATE', payload: newState });
      }
    });

    return () => {
      socket.off('state_updated');
    };
  }, [socket]);

  return (
    <DraftContext.Provider value={{ state, dispatch }}>
      {children}
    </DraftContext.Provider>
  );
}

export function useDraft() {
  const context = useContext(DraftContext);
  if (!context) {
    throw new Error('useDraft must be used within a DraftProvider');
  }
  return context;
}