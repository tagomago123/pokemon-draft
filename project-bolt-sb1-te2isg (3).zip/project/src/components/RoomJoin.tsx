import React, { useState } from 'react';
import { useSocket } from '../contexts/SocketContext';
import { Share2, Users, AlertCircle, Loader2 } from 'lucide-react';

export default function RoomJoin() {
  const { createRoom, joinRoom, roomId, error, isConnecting } = useSocket();
  const [joinRoomId, setJoinRoomId] = useState('');

  const handleJoinRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (joinRoomId.trim()) {
      joinRoom(joinRoomId.trim().toUpperCase());
    }
  };

  if (roomId) {
    return (
      <div className="fixed top-4 right-4 bg-white rounded-lg shadow-lg p-4">
        <div className="flex items-center gap-2 mb-2">
          <Share2 className="w-5 h-5 text-blue-600" />
          <h3 className="font-semibold">Room Code</h3>
        </div>
        <div className="flex items-center gap-2">
          <code className="bg-gray-100 px-3 py-1 rounded text-lg font-mono">
            {roomId}
          </code>
          <button
            onClick={() => navigator.clipboard.writeText(roomId)}
            className="text-blue-600 hover:text-blue-700 text-sm"
          >
            Copy
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-lg p-8 max-w-md w-full">
        <div className="flex items-center gap-3 mb-6">
          <Users className="w-6 h-6 text-blue-600" />
          <h2 className="text-2xl font-bold text-gray-800">Join Pokémon Draft</h2>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
            <AlertCircle className="w-5 h-5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        )}

        <div className="space-y-6">
          <button
            onClick={createRoom}
            disabled={isConnecting}
            className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
          >
            {isConnecting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Connecting...
              </>
            ) : (
              'Create New Draft'
            )}
          </button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">or join existing</span>
            </div>
          </div>

          <form onSubmit={handleJoinRoom}>
            <div className="mb-4">
              <label
                htmlFor="roomCode"
                className="block text-sm font-medium text-gray-700 mb-2"
              >
                Enter Room Code
              </label>
              <input
                id="roomCode"
                type="text"
                value={joinRoomId}
                onChange={(e) => setJoinRoomId(e.target.value.toUpperCase())}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter 6-digit code"
                maxLength={6}
                disabled={isConnecting}
              />
            </div>
            <button
              type="submit"
              disabled={isConnecting}
              className="w-full bg-gray-800 hover:bg-gray-900 disabled:bg-gray-400 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
            >
              {isConnecting ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Connecting...
                </>
              ) : (
                'Join Draft'
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}