export interface Pokemon {
  name: string;
  url: string;
  sprite: string;
}

export interface DraftUser {
  id: string;
  name: string;
  selections: Pokemon[];
}