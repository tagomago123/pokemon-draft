# Pokémon Draft

A real-time Pokémon drafting application built with React, Socket.IO, and Vite.

## Prerequisites

- Node.js >= 18.0.0
- npm >= 9.0.0

## Development

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm run dev
```

## Production Build

```bash
npm run build
```

## Running the Server

```bash
npm run server
```

## Starting Both Client and Server

```bash
npm start
```