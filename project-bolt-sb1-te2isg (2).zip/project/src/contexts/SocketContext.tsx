import React, { createContext, useContext, useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';

interface SocketContextType {
  socket: Socket | null;
  roomId: string | null;
  createRoom: () => void;
  joinRoom: (roomId: string) => void;
  error: string | null;
  isConnecting: boolean;
}

const SocketContext = createContext<SocketContextType | null>(null);

const SOCKET_URL = window.location.hostname === 'localhost' 
  ? 'http://localhost:3001'
  : window.location.origin;

export function SocketProvider({ children }: { children: React.ReactNode }) {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [roomId, setRoomId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(true);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);

  useEffect(() => {
    const newSocket = io(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 20000,
      autoConnect: true,
      forceNew: true,
    });

    newSocket.on('connect', () => {
      setError(null);
      setIsConnecting(false);
      setReconnectAttempts(0);
    });

    newSocket.on('connect_error', () => {
      setReconnectAttempts((prev) => prev + 1);
      setIsConnecting(true);
      
      if (reconnectAttempts >= 5) {
        setError('Unable to connect to server. Please try refreshing the page.');
        setIsConnecting(false);
      } else {
        setError('Connecting to server...');
      }
    });

    newSocket.on('disconnect', (reason) => {
      setIsConnecting(true);
      
      if (reason === 'io server disconnect') {
        newSocket.connect();
      } else {
        setError('Connection lost. Trying to reconnect...');
      }
    });

    setSocket(newSocket);

    return () => {
      newSocket.close();
    };
  }, [reconnectAttempts]);

  useEffect(() => {
    if (!socket) return;

    const handleRoomCreated = (newRoomId: string) => {
      setRoomId(newRoomId);
      setError(null);
    };

    const handleRoomJoined = (state: { roomId: string }) => {
      setRoomId(state.roomId);
      setError(null);
    };

    const handleError = (message: string) => {
      setError(message);
    };

    socket.on('room_created', handleRoomCreated);
    socket.on('room_joined', handleRoomJoined);
    socket.on('error', handleError);

    return () => {
      socket.off('room_created', handleRoomCreated);
      socket.off('room_joined', handleRoomJoined);
      socket.off('error', handleError);
    };
  }, [socket]);

  const createRoom = () => {
    if (!socket?.connected) {
      setError('Not connected to server. Please wait and try again.');
      return;
    }
    socket.emit('create_room');
  };

  const joinRoom = (roomId: string) => {
    if (!socket?.connected) {
      setError('Not connected to server. Please wait and try again.');
      return;
    }
    socket.emit('join_room', roomId);
  };

  return (
    <SocketContext.Provider value={{ 
      socket, 
      roomId, 
      createRoom, 
      joinRoom, 
      error,
      isConnecting 
    }}>
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
}